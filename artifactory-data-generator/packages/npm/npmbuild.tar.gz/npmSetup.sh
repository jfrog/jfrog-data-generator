#!/bin/bash
set -e;
setup()
{
echo "email = mail@to.com" >> ~/.npmrc;
echo 'Running the following command to get NPM auth: curl -s -u$ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD "$ARTIFACTORY_URL/api/npm/auth"';
curl -u${ARTIFACTORY_USER}:${ARTIFACTORY_PASSWORD} "${ARTIFACTORY_URL}/api/npm/auth" >> ~/.npmrc || true; #To continue in case of failure
npm config set registry ${ARTIFACTORY_URL}/api/npm/npm
}
setup